"""SSH-agent implementation using hardware authentication devices."""
